"""Demostración visual del historial musical mediante Tkinter.
Utiliza la clase original HistorialMusical sin modificarla.
Ejecutar: python p1_504660648_visual.py
"""
import tkinter as tk
from tkinter import ttk, messagebox
from p1_504660648_Estructura import HistorialMusical

BG = '#0c1220'
PANEL = '#182338'
TEXT = '#f4f7ff'
MUTED = '#a9bad1'
ACCENT = '#6ce6c3'
OUTLINE = '#36516b'


class VisualHistorial:
    def __init__(self, root):
        self.root = root
        self.root.title('Historial musical | Lista doblemente enlazada')
        self.root.geometry('1040x690')
        self.root.minsize(790, 600)
        self.root.configure(bg=BG)
        self.historial = HistorialMusical()
        for titulo, artista in [('Canción A', 'Artista A'), ('Canción B', 'Artista B'), ('Canción C', 'Artista C')]:
            self.historial.agregar_cancion(titulo, artista)
        self.crear_interfaz()
        self.redibujar('Historial cargado con tres canciones. Seleccionada: Canción A.')

    def crear_interfaz(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill='x', padx=24, pady=(20, 12))
        tk.Label(header, text='HISTORIAL MUSICAL', bg=BG, fg=TEXT, font=('Segoe UI', 23, 'bold')).pack(anchor='w')
        tk.Label(header, text='Proyecto de Estructuras de Datos  •  Lista doblemente enlazada', bg=BG, fg=MUTED, font=('Segoe UI', 11)).pack(anchor='w')

        detail = tk.Frame(self.root, bg=PANEL, padx=16, pady=12)
        detail.pack(fill='x', padx=24, pady=(0, 14))
        self.estado = tk.Label(detail, text='', bg=PANEL, fg=ACCENT, font=('Segoe UI', 13, 'bold'), anchor='w')
        self.estado.pack(fill='x')
        self.explicacion = tk.Label(detail, text='', bg=PANEL, fg=MUTED, font=('Segoe UI', 10), anchor='w', justify='left', wraplength=900)
        self.explicacion.pack(fill='x', pady=(4, 0))

        self.canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0, height=260)
        self.canvas.pack(fill='both', expand=True, padx=24)
        self.canvas.bind('<Configure>', lambda _: self.dibujar_nodos())

        form = tk.Frame(self.root, bg=PANEL, padx=16, pady=16)
        form.pack(fill='x', padx=24, pady=(8, 12))
        tk.Label(form, text='Título', bg=PANEL, fg=TEXT, font=('Segoe UI', 10)).grid(row=0, column=0, sticky='w')
        tk.Label(form, text='Artista (para agregar)', bg=PANEL, fg=TEXT, font=('Segoe UI', 10)).grid(row=0, column=1, sticky='w', padx=(12, 0))
        self.titulo = ttk.Entry(form, font=('Segoe UI', 11), width=28)
        self.artista = ttk.Entry(form, font=('Segoe UI', 11), width=25)
        self.titulo.grid(row=1, column=0, sticky='ew', pady=(4, 10))
        self.artista.grid(row=1, column=1, sticky='ew', padx=(12, 0), pady=(4, 10))
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        botones = tk.Frame(form, bg=PANEL)
        botones.grid(row=2, column=0, columnspan=2, sticky='ew')
        opciones = [
            ('+ Agregar', self.agregar), ('← Retroceder', self.retroceder),
            ('Avanzar →', self.avanzar), ('Buscar', self.buscar),
            ('Eliminar', self.eliminar), ('Reiniciar', self.reiniciar),
        ]
        for index, (etiqueta, comando) in enumerate(opciones):
            tk.Button(botones, text=etiqueta, command=comando, bg=('#176b5b' if index == 0 else '#283f5a'), fg='white', activebackground='#3e6589', activeforeground='white', relief='flat', cursor='hand2', font=('Segoe UI', 10, 'bold'), padx=12, pady=10).pack(side='left', padx=(0, 8), pady=2)

        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill='x', padx=26, pady=(0, 15))
        self.log = tk.Label(footer, text='', bg=BG, fg=MUTED, font=('Segoe UI', 10), anchor='w', justify='left', wraplength=970)
        self.log.pack(fill='x')

    def redibujar(self, mensaje):
        nodo = self.historial.actual
        self.estado.config(text=f'♫  Canción actual: {nodo.titulo} — {nodo.artista}' if nodo else '♫  Historial vacío')
        self.explicacion.config(text='Verde = nodo actual   ·   Flechas dobles = enlaces anterior y siguiente   ·   PRIMERA y ÚLTIMA = extremos de la lista')
        self.log.config(text='Operación: ' + mensaje)
        self.dibujar_nodos()

    def dibujar_nodos(self):
        c = self.canvas
        c.delete('all')
        nodos = list(self.historial.recorrer())
        w = max(c.winfo_width(), 740)
        h = max(c.winfo_height(), 215)
        if not nodos:
            c.create_text(w / 2, h / 2, text='No hay canciones. Agregá una para crear el primer nodo.', fill=MUTED, font=('Segoe UI', 14))
            return
        card_w, card_h, gap = 150, 94, 58
        per_row = max(1, min(len(nodos), int((w - 35 + gap) // (card_w + gap))))
        rows = (len(nodos) + per_row - 1) // per_row
        if rows > 2:
            c.create_text(w / 2, 16, text='Historial largo: cada fila continúa en la siguiente (los enlaces siguen activos).', fill=MUTED, font=('Segoe UI', 9))
        positions = []
        top = 46
        for i, nodo in enumerate(nodos):
            row, col = divmod(i, per_row)
            count = min(per_row, len(nodos) - row * per_row)
            x0 = (w - (count * card_w + (count - 1) * gap)) / 2
            x = x0 + col * (card_w + gap)
            y = top + row * 160
            positions.append((x, y))
            color = ACCENT if nodo is self.historial.actual else OUTLINE
            c.create_rectangle(x, y, x + card_w, y + card_h, outline=color, width=3 if nodo is self.historial.actual else 2, fill=PANEL)
            titulo = nodo.titulo if len(nodo.titulo) <= 19 else nodo.titulo[:17] + '…'
            artista = nodo.artista if len(nodo.artista) <= 22 else nodo.artista[:20] + '…'
            c.create_text(x + card_w / 2, y + 30, text=titulo, fill=TEXT, font=('Segoe UI', 12, 'bold'))
            c.create_text(x + card_w / 2, y + 54, text=artista, fill=MUTED, font=('Segoe UI', 10))
            labels = []
            if nodo is self.historial.primera: labels.append('PRIMERA')
            if nodo is self.historial.ultima: labels.append('ÚLTIMA')
            if nodo is self.historial.actual: labels.append('ACTUAL')
            c.create_text(x + card_w / 2, y + card_h + 16, text='  ·  '.join(labels), fill=ACCENT if nodo is self.historial.actual else MUTED, font=('Segoe UI', 9, 'bold'))
        for i in range(len(positions) - 1):
            x, y = positions[i]
            xx, yy = positions[i + 1]
            if yy == y:
                a = x + card_w + 4
                b = xx - 4
                c.create_line(a, y + 31, b, y + 31, fill=ACCENT, arrow=tk.LAST, width=2)
                c.create_line(b, y + 66, a, y + 66, fill=ACCENT, arrow=tk.LAST, width=2)
            else:
                c.create_line(x + card_w/2, y + card_h + 29, xx + card_w/2, yy - 8, fill=OUTLINE, dash=(5, 4), width=2)
        c.configure(scrollregion=(0, 0, w, max(h, top + rows * 160)))

    def agregar(self):
        try:
            nodo = self.historial.agregar_cancion(self.titulo.get(), self.artista.get())
        except ValueError as error:
            messagebox.showwarning('Datos incompletos', str(error))
            return
        self.redibujar(f'Se agregó {nodo.titulo}. Se enlaza con la anterior última canción.')
        self.titulo.delete(0, tk.END)
        self.artista.delete(0, tk.END)

    def avanzar(self):
        if self.historial.avanzar():
            self.redibujar('actual = actual.siguiente; se avanzó a la próxima canción.')
        else:
            self.redibujar('No se puede avanzar: no existe una canción siguiente.')

    def retroceder(self):
        if self.historial.retroceder():
            self.redibujar('actual = actual.anterior; se regresó a la canción previa.')
        else:
            self.redibujar('No se puede retroceder: no existe una canción anterior.')

    def buscar(self):
        nodo = self.historial.buscar_cancion(self.titulo.get())
        if nodo is None:
            self.redibujar('No se encontró la canción solicitada.')
        else:
            # buscar no cambia self.actual en la implementación original
            self.redibujar(f'Se encontró {nodo.titulo} de {nodo.artista}. Buscar no modifica la canción actual.')

    def eliminar(self):
        titulo = self.titulo.get().strip()
        if not titulo:
            messagebox.showwarning('Título requerido', 'Escribí el título que querés eliminar.')
            return
        if self.historial.eliminar_cancion(titulo):
            self.redibujar(f'Se eliminó {titulo}. Se reconectaron los vecinos y se actualizó actual si correspondía.')
            self.titulo.delete(0, tk.END)
        else:
            self.redibujar(f'No existe una canción llamada {titulo}.')

    def reiniciar(self):
        self.historial = HistorialMusical()
        for titulo, artista in [('Canción A', 'Artista A'), ('Canción B', 'Artista B'), ('Canción C', 'Artista C')]:
            self.historial.agregar_cancion(titulo, artista)
        self.redibujar('Se restauraron las canciones A, B y C para repetir la demostración.')


if __name__ == '__main__':
    ventana = tk.Tk()
    VisualHistorial(ventana)
    ventana.mainloop()
